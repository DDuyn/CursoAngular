export const es = {
    "title" : "Bienvenido",
    "subtitle": "Disfruta de nuestros libros",
    "home": "Inicio",
    "products": "Productos"
}