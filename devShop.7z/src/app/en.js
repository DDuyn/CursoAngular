export const en = {
    "title" : "Welcome",
    "subtitle": "Enjoy our books!",
    "home": "Home",
    "products": "Products"
}
