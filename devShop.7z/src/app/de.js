export const de = {
    "title" : "Willkommen",
    "subtitle": "Viel Spaß mit unseren Büchern",
    "home": "Zuhause",
    "products": "Produkte"
}