import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { AppComponent } from './app.component';
import { WelcomeComponent } from './welcome/welcome.component';
import { ListItemComponent } from './list-item/list-item.component';
import { DetailItemComponent } from './detail-item/detail-item.component';
import { FilterItemsPipe } from './filter-items.pipe';
import { TranslatePipe } from './translate.pipe';
import { HttpClientModule } from '@angular/common/http'
import { CartItemComponent } from './cart-item/cart-item.component';
import { QuantityItemComponent } from './quantity-item/quantity-item.component';
import { ItemDetailResolverService } from './item-detail-resolver.service';
import { LoginComponent } from './login/login.component';
import { AppRouterModule } from './app-router/app-router.module';
import { CoreModule } from './core/core.module';
import { RatingModule, ModalModule } from 'ngx-bootstrap'
import { ItemModule } from './item/item.module';
import { SharedModule } from './shared/shared.module';
import { EditItemComponent } from './edit-item/edit-item.component';


@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    TranslatePipe,
    CartItemComponent,
    LoginComponent
  ],
  imports: [
    CoreModule,
    AppRouterModule,
    BrowserModule,
    FormsModule,
    HttpClientModule,
    SharedModule,
    ReactiveFormsModule
  ],
  providers: [
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }